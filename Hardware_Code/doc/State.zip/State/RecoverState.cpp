/**
 * Project Untitled
 */


#include "RecoverState.h"

/**
 * RecoverState implementation
 */


/**
 * @param wallet
 */
void RecoverState::execute(Wallet* wallet) {

}