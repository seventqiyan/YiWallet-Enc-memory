/**
 * Project Untitled
 */


#ifndef _RECOVERSTATE_H
#define _RECOVERSTATE_H

#include "WalletState.h"


class RecoverState: public WalletState {
public: 
    
    /**
     * @param wallet
     */
    void execute(Wallet* wallet);
};

#endif //_RECOVERSTATE_H