/**
 * Project Untitled
 */


#ifndef _NORMALSTATE_H
#define _NORMALSTATE_H

#include "WalletState.h"


class NormalState: public WalletState {
public: 
    
    /**
     * @param wallet
     */
    void execute(Wallet* wallet);
};

#endif //_NORMALSTATE_H