/**
 * Project Untitled
 */


#ifndef _ERRORSTATE_H
#define _ERRORSTATE_H

#include "WalletState.h"


class ErrorState: public WalletState {
public: 
    
    /**
     * @param wallet
     */
    void execute(Wallet* wallet);
};

#endif //_ERRORSTATE_H