/**
 * Project Untitled
 */


#include "NormalState.h"

/**
 * NormalState implementation
 */


/**
 * @param wallet
 */
void NormalState::execute(Wallet* wallet) {
    wallet->normal();
}