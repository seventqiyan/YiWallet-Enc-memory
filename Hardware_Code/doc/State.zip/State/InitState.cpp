/**
 * Project Untitled
 */


#include "InitState.h"

/**
 * InitState implementation
 */


/**
 * @param wallet
 */
void InitState::execute(Wallet* wallet) {
    wallet->initPassword();
}