/**
 * Project Untitled
 */


#include "CheckUIDState.h"

/**
 * InitState implementation
 */


/**
 * @param wallet
 */
void CheckUIDState::execute(Wallet* wallet) {
    if (wallet->checkUID()) {
        wallet->setState(Wallet::WS_INIT_PASSWD);
    }
}
