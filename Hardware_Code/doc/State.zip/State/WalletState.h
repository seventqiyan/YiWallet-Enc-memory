/**
 * Project Untitled
 */


#ifndef _WALLETSTATE_H
#define _WALLETSTATE_H

class Wallet;
class WalletState {
public: 
    /**
     * @param wallet
     */
    virtual void execute(Wallet* wallet) = 0;

protected:
};

#include "Wallet.h"
#include "CheckUIDState.h"
#include "ErrorState.h"
#include "InitState.h"
#include "Init2State.h"
#include "NormalState.h"
#include "RecoverState.h"

#endif //_WALLETSTATE_H