/**
 * Project Untitled
 */


#ifndef _CHECK_UID_STATE_H_
#define _CHECK_UID_STATE_H_

#include "WalletState.h"


class CheckUIDState: public WalletState {
public: 
    
    /**
     * @param wallet
     */
    void execute(Wallet* wallet);
};

#endif //_CHECK_UID_STATE_H_