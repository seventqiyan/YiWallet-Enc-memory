/**
 * Project Untitled
 */


#ifndef _INIT2STATE_H
#define _INIT2STATE_H

#include "WalletState.h"


class Init2State: public WalletState {
public: 
    
    /**
     * @param wallet
     */
    void execute(Wallet* wallet);
};

#endif //_INIT2STATE_H