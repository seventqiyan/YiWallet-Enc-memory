/**
 * Project Untitled
 */


#include "Init2State.h"

/**
 * Init2State implementation
 */


/**
 * @param wallet
 */
void Init2State::execute(Wallet* wallet) {
    wallet->initBccInfo();
}