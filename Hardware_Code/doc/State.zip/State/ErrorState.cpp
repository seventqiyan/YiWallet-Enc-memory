/**
 * Project Untitled
 */


#include "ErrorState.h"

/**
 * ErrorState implementation
 */


/**
 * @param wallet
 */
void ErrorState::execute(Wallet* wallet) {

}