/**
 * Project Untitled
 */


#ifndef _INITSTATE_H
#define _INITSTATE_H

#include "WalletState.h"


class InitState: public WalletState {
public: 
    
    /**
     * @param wallet
     */
    void execute(Wallet* wallet);
};

#endif //_INITSTATE_H